- This is it for now there will be more added here soon

- If there is an update either I added some more code or I got suggested some code to add